let pg=1

document.querySelector(".new_btn").addEventListener("click",function(){
    let account_info = document.querySelector(".val_login_info").getAttribute("id")
    if (account_info == "loginrequired"){
        alert("로그인이 필요한 기능입니다.")
        window.location.href = '/accounts/login';
        return false
    }else{
    document.querySelector("#edit").setAttribute("class","display")
}
})

let more_btn=document.querySelectorAll("p.more")
let tg_div=document.querySelectorAll("div.undisplay")
for (let i=0;i<more_btn.length;i++){
let more_btn_this = more_btn[i]
let tg_div_this = tg_div[i]
let id = tg_div_this.parentNode.getAttribute("id")
more_btn_this.addEventListener("click",function(f){
    f.stopPropagation();
    tg_div_this.classList.toggle("undisplay")
    })
//tg_div[i].childNodes[1].addEventListener("click",function(){
//
//}) >> 편집버튼
tg_div[i].childNodes[3].addEventListener("click",function(e){
    e.stopPropagation();
    if (window.confirm("정말 삭제하시겠습니까?")){
        window.location.href = '/community/detail/delete/'+id
    }else{
    return false
}},false)}


document.querySelector("textarea#content").addEventListener("keypress",function(e){
    let account_info = document.querySelector(".val_login_info").getAttribute("id")
    if (account_info == "loginrequired"){
        document.querySelector("textarea#content").value=null
        alert("로그인이 필요한 기능입니다.")
        window.location.href = 'accounts/login';
        return false
    }
    else{
     document.querySelector("#textlen").innerHTML=Number(document.querySelector("textarea#content").value.length);    }
    },false)


document.querySelector("textarea#content").addEventListener("keyup",function(e){
    let account_info = document.querySelector(".val_login_info").getAttribute("id")
    if (account_info == "loginrequired"){
        document.querySelector("textarea#content").value=null
        alert("로그인이 필요한 기능입니다.")
        window.location.href = 'accounts/login';
        return false
    }
    else{
     document.querySelector("#textlen").innerHTML=Number(document.querySelector("textarea#content").value.length);    }
    },false)


function DataListener(e){
console.log(e.currentTarget.response)}

let areq = new XMLHttpRequest()
let addr="/?"+"page=2"
areq.addEventListener("load",DataListener);
areq.open("GET",addr)
areq.send();

document.querySelector("div.next_page").addEventListener("click",function(){
window.location.href = '/community/?page='+((parseInt(window.location.href.split("=")[1]))+1);
})



//
//pg=pg+1
//let url="127.0.0.1:8000/community?="+pg
//xmlHttp=createXMLHTTPObject();
//xmlHttp.open("get",xmlHttp,true);
//xmlHttp.onreadystatechange=on_readyStateChance;
//xmlHttp.send(null;)
//
//pg=pg+1
//httpRequest = new XMLHttpRequest();
//httpRequest.onreadystatechange = () => {
// if (httpRequest.readyState === XMLHttpRequest.DONE) {
//			      if (httpRequest.status === 201) {
//			    	let result = httpRequest.response;
//					// {url: 'https://todo-app-react-django-backend.herokuapp.com/tasks/8/', item: 'hi', created_at: '2022-06-13T08:05:05.679910Z', user: 'admin'}
//					// 형태의 응답코드가 온다.
//					console.log(result);
//			      } else {
//					console.log(httpRequest);
//			        alert('bad request.');
//			      }
//			}
//	    };
//
//

//function comment_count(){
//    console.log("todo_count")
//    let xhr = new XMLHttpRequest();
//    xhr.onreadystatechange = () =>{
//    if(xhr.readyState === XMLHttpRequest.DONE){
//    if(xhr.status===200){
//    let res = xhr.response;
//    document.getElementById("likes_p").innerText=res.count;
//    }else{
//    alert("bad Request");
//    }
//    }
//    }
//    xhr.open("GET","http://127.0.0.1:8000/api/todos/count")
//    xhr.responseType="json";
//    xhr.send();
//}
//todo_count();
//console.log("cookie")