document.querySelector(".go_list").addEventListener("click",function(){
    window.location.href = '/qna'
})

let del_btn = document.querySelector(".delete")
del_btn.addEventListener("click",function(){
    let account_info = document.querySelector(".val_login_info").getAttribute("id")
    if (account_info == "loginrequired"){
        alert("로그인이 필요한 기능입니다.")
        window.location.href = '/accounts/login';
        return false
    }else{
    if (window.confirm("정말 삭제하시겠습니까?")){
        let id=del_btn.getAttribute("id")
        window.location.href = '/qna/delete/'+id
    }else{
    return false
    }
}})

let mod_btn = document.querySelector(".modify")
mod_btn.addEventListener("click",function(){
    let id=mod_btn.getAttribute("id")
    window.location.href = '/qna/editor/'+id
})

