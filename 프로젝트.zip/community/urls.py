# from rest_framework.urlpatterns import  format_suffix_patterns
from django.urls import path,include
from . import views
# from .views import CommentView
# from django.contrib.auth import views as auth_view

app_name="community"

#
# todo_list = CommentView.as_view({
#     "post":"create",
#     "get":"list"
# })
#
# todo_detail = CommentView.as_view({
#     "get":"retrieve",
#     "put":"update",
#     "patch":"partial_update",
#     "delete":"destroy"
# })

urlpatterns = [
    path("", views.community, name="content_list"),
    path("<str:content_category>", views.filter_category, name="content_list_category"),
    # path("detail/<int:content_id>/<int:comment_id>", views.comment_edit, name="comment_editor"),
    path("detail/<int:content_id>",views.detail,name="content_detail"),
    path("detail/delete/<int:content_id>",views.delete,name="content_delete"),
    # path("api/count/",views.CountLikes, name="likes_count")
]