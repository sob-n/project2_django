document.querySelector("#form").addEventListener('click',function(){
    let account_info = document.querySelector(".val_login_info").getAttribute("id")
    if (account_info == "loginrequired"){
    window.location.href = "/accounts/login";
    //url 수정
    alert("로그인이 필요한 기능입니다.")
    return false
    }
    else{
    window.location.href = '/qna/editor';
    //url 수정
    }
    }, false);