document.querySelector("textarea#comment").addEventListener("keypress",function(e){
    e.stopPropagation();
    let account_info = document.querySelector(".val_login_info").getAttribute("id")
    if (account_info == "loginrequired"){
        document.querySelector("textarea#comment").value=null
        alert("로그인이 필요한 기능입니다.")
        window.location.href = '/accounts/login';
        return false
    }
})
document.querySelector(".go_list").addEventListener("click",function(){
    window.location.href = '/community'
})

let del_btn=document.querySelectorAll(".delete")
for(let i=0;i<del_btn.length;i++){
del_btn[i].addEventListener("click",function(e){
e.stopPropagation();
if (window.confirm("정말 삭제하시겠습니까?")){
    let id = del_btn[i].parentElement.getAttribute("id")
    let cnt_id=window.location.href.split("/")[5]
        window.location.href = ('delete/'+cnt_id+'/reply_delete/'+id)
    }else{
    return false
    }
})
}