from django.shortcuts import render,redirect
from django.utils import timezone
from  .models import Community,Comment
from django.core.paginator import Paginator,PageNotAnInteger,EmptyPage

from django.contrib.auth.decorators import login_required


from django.http import HttpResponse
#
def community(request):
    if request.method == "GET":
        content_list = Community.objects.order_by("create_date")[::-1]
        comment_list = Comment.objects.order_by("create_date")
        page=request.GET.get('page')
        paginator = Paginator(content_list, 10)
        try:
            page_obj = paginator.page(page)
        except PageNotAnInteger:
            page = 1
            page_obj = paginator.page(page)
        except EmptyPage:
            page = paginator.num_pages
            page_obj = paginator.page(page)
        finally:
            comment_count, likes_count = [], []
            z = []
            for i in range(0, len(page_obj)):
                comments = Comment.objects.filter(content_id=page_obj[i].id, comment__isnull=False).count()
                likes = Comment.objects.filter(content_id=page_obj[i].id, likes=1).count()
                comment_count.append(comments)
                likes_count.append(likes)
                try:
                    user_like = Comment.objects.filter(content_id=page_obj[i].id, author=request.user, likes=1)
                    z.append(user_like)
                except:
                    pass
            return render(request, 'community/community.html',
                          {"likes_count": likes_count, "comment_count": comment_count, "page_obj": page_obj, "z": z})
    else:
        feed = Community(
            content=request.POST.get('content'),
            create_date=timezone.now(),
            author=request.user,
            # region=request.user,
            category=request.POST.get('category'))
        feed.save()
        return redirect("/community/")

def filter_category(request,content_category):
    if request.method == "GET":
        content_list = Community.objects.filter(category=content_category)[::-1]
        comment_list = Comment.objects.order_by("create_date")
        page = request.GET.get('page')
        paginator = Paginator(content_list, 10)
        try:
            page_obj = paginator.page(page)
        except PageNotAnInteger:
            page = 1
            page_obj = paginator.page(page)
        except EmptyPage:
            page = paginator.num_pages
            page_obj = paginator.page(page)
        finally:
            comment_count, likes_count = [], []
            z = []
            for i in range(0, len(page_obj)):
                comments = Comment.objects.filter(content_id=page_obj[i].id, comment__isnull=False).count()
                likes = Comment.objects.filter(content_id=page_obj[i].id, likes=1).count()
                comment_count.append(comments)
                likes_count.append(likes)
                try:
                    user_like = Comment.objects.filter(content_id=page_obj[i].id, author=request.user, likes=1)
                    z.append(user_like)
                except:
                    pass
            return render(request, 'community/community.html',
                          {"likes_count": likes_count, "comment_count": comment_count, "page_obj": page_obj, "z": z})
    else:
        feed = Community(
            content=request.POST.get('content'),
            create_date=timezone.now(),
            author=request.user,
            # region=request.user,
            category=request.POST.get('category'))
        feed.save()
        return redirect("/community/")


def detail(request,content_id):
    content=Community.objects.get(id=content_id)
    comment_list=Comment.objects.filter(content_id=content_id)
    if request.method == "GET":
        return render(request, "community/community_detail.html", {"content": content, "comment_list": comment_list})
    else:
        comment = Comment(
            author=request.user,
            create_date=timezone.now(),
            content_id=content_id,
            comment=request.POST.get('comment'))
        comment.save()
        loc=str("/community/detail/"+str(content_id))
        return redirect(loc)

def delete(request,content_id):
    content = Community.objects.get(id=content_id)
    content.delete()
    return redirect("/community")

def comment(request):
    content_list = Community.objects.order_by("create_date")[::-1]
    paginator = Paginator(content_list, 10)
    page = 1
    page_obj = paginator.page(page)

    z=[]
    for i in range(0,10):
        comments = Comment.objects.filter(content_id=page_obj[i].id).count()
        z.append(comments)
    return render(request, 'community/new.html',{"z":z})

def comment_delete(request,content_id,comment_id):
    comment = Comment.objects.get(id=comment_id)
    comment.delete()
    return redirect("/community/detail/"+str(content_id))
#
# def likes_toggle(request,comment_id):
#     comment=Comment.likes